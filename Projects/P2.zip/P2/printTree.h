//
// Created by crbaniak on 5/16/19.
//

#ifndef P1_PRINTTREE_H
#define P1_PRINTTREE_H

#include "node.h"

void printTree(node*,int);

#endif //P1_PRINTTREE_H
