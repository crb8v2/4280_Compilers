//
// Created by crbaniak on 5/20/19.
//

#ifndef P1_STATSEM_H
#define P1_STATSEM_H

#include "scanner.h"

void statSem();

#endif //P1_STATSEM_H
